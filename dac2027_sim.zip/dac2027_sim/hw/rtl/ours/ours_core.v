// ours_core.v -- synthesizable core of the DAC2027 design (DAC2027_accelerator_explained_rows.pdf), sized like
// the cycle model's base point (dac2027_sim/ours.py Cfg()):
//   R x C = 4 x 4 weight-stationary PEs, T = 8 gated adders per PE, F = 4 filters per column (2-bit filter
//   label per weight), G = 4 pixels per group (2-bit pixel label per spike bit), double-buffered (shadow)
//   weights, running sums of SW = 10 bits per (filter, pixel, timestep) inside the array (R * 127 < 2^9),
//   edge unit with an 80-entry FIFO per column (16 writes, E = 4 read-modify-writes per cycle, 24-bit sums),
//   16 leaky LIF units, and the run-time packer (8 pixel slices per cycle, first-fit, 4 open groups).
// Not inside the core (SRAM, the same exclusion as for LoAS/PTB/SpikeX): weight memory, spike memory, group
// buffer, output buffer. The output buffer is accessed through the obuf_* read-modify-write ports.
`timescale 1ns/1ps

module ours_pe #(parameter T = 8, F = 4, G = 4, SW = 10) (
    input  wire                  clk, rst,
    input  wire                  wl_en, wl_par,
    input  wire signed [7:0]     wl_w,
    input  wire [1:0]            wl_f,
    input  wire                  i_v, i_par,
    input  wire [T-1:0]          i_bits,
    input  wire [2*T-1:0]        i_lab,
    input  wire [F*G*T*SW-1:0]   b_sum,
    input  wire [F*G-1:0]        b_tch,
    output reg                   o_v, o_par,
    output reg  [T-1:0]          o_bits,
    output reg  [2*T-1:0]        o_lab,
    output reg  [F*G*T*SW-1:0]   ob_sum,
    output reg  [F*G-1:0]        ob_tch
);
    localparam NS = F * G;
    reg signed [7:0] wa, ws;      // active / shadow weight
    reg [1:0] fa, fs;             // active / shadow filter label
    reg pa, ps;                   // pass parity of active / shadow
    wire swap = i_v && (i_par != pa);
    wire signed [7:0] w = swap ? ws : wa;
    wire [1:0] f = swap ? fs : fa;

    reg [F*G*T*SW-1:0] nsum;
    reg [NS-1:0] ntch;
    reg [3:0] slot;
    reg signed [SW-1:0] old, add;
    integer t, s;
    always @(*) begin
        nsum = b_sum;
        ntch = b_tch;
        for (t = 0; t < T; t = t + 1) begin
            slot = {f, i_lab[2*t +: 2]};
            old = b_sum[(slot * T + t) * SW +: SW];
            add = old + {{(SW-8){w[7]}}, w};
            if (i_v && i_bits[t] && (w != 0)) begin
                for (s = 0; s < NS; s = s + 1)
                    if (slot == s) begin
                        nsum[(s * T + t) * SW +: SW] = add;
                        ntch[s] = 1'b1;
                    end
            end
        end
    end

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            wa <= 0; ws <= 0; fa <= 0; fs <= 0; pa <= 0; ps <= 0;
            o_v <= 0; o_par <= 0; o_bits <= 0; o_lab <= 0; ob_sum <= 0; ob_tch <= 0;
        end else begin
            if (swap) begin wa <= ws; fa <= fs; pa <= ps; end
            if (wl_en) begin ws <= wl_w; fs <= wl_f; ps <= wl_par; end
            o_v <= i_v; o_par <= i_par;
            o_bits <= i_v ? i_bits : {T{1'b0}};
            o_lab <= i_v ? i_lab : {2*T{1'b0}};
            ob_sum <= nsum;
            ob_tch <= i_v ? ntch : {NS{1'b0}};
        end
    end
endmodule


// 80-entry FIFO, up to 16 writes (the touched slots of one bundle) and 4 reads per cycle.
// Banked: entry n lives in bank n%16, row n/16, so 16 consecutive writes always hit 16 different banks.
module ours_edge_fifo #(parameter EW = 93, NS = 16, BANKS = 16, ROWS = 5, E = 4) (
    input  wire               clk, rst,
    input  wire [NS-1:0]      wr_v,          // which slots carry an entry
    input  wire [NS*EW-1:0]   wr_d,
    output wire [E-1:0]       rd_v,
    output wire [E*EW-1:0]    rd_d,
    output reg  [7:0]         count,
    output reg                overflow
);
    localparam D = BANKS * ROWS;
    reg [EW-1:0] mem [0:D-1];
    reg [6:0] wptr, rptr;
    // ranks of the written slots
    reg [4:0] rank [0:NS-1];
    reg [4:0] nwr;
    integer s, b, i;
    always @(*) begin
        nwr = 0;
        for (s = 0; s < NS; s = s + 1) begin
            rank[s] = nwr;
            nwr = nwr + wr_v[s];
        end
    end
    wire [2:0] nrd = (count >= E) ? E : count[2:0];
    // per-bank write select
    reg [EW-1:0] bdata [0:BANKS-1];
    reg [BANKS-1:0] bwe;
    reg [2:0] brow [0:BANKS-1];
    reg [6:0] dest;
    always @(*) begin
        for (b = 0; b < BANKS; b = b + 1) begin bwe[b] = 0; bdata[b] = 0; brow[b] = 0; end
        for (s = 0; s < NS; s = s + 1) begin
            dest = (wptr + rank[s] >= D) ? wptr + rank[s] - D : wptr + rank[s];
            if (wr_v[s]) begin
                bwe[dest % BANKS] = 1'b1;
                bdata[dest % BANKS] = wr_d[s*EW +: EW];
                brow[dest % BANKS] = dest / BANKS;
            end
        end
    end
    genvar g;
    generate for (g = 0; g < E; g = g + 1) begin : rp
        wire [6:0] a = (rptr + g >= D) ? rptr + g - D : rptr + g;
        assign rd_v[g] = (g < nrd);
        assign rd_d[g*EW +: EW] = mem[a];
    end endgenerate
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            wptr <= 0; rptr <= 0; count <= 0; overflow <= 0;
        end else begin
            for (b = 0; b < BANKS; b = b + 1)
                if (bwe[b]) mem[brow[b] * BANKS + b] <= bdata[b];
            wptr <= (wptr + nwr >= D) ? wptr + nwr - D : wptr + nwr;
            rptr <= (rptr + nrd >= D) ? rptr + nrd - D : rptr + nrd;
            count <= count + nwr - nrd;
            if (count + nwr - nrd > D) overflow <= 1'b1;
        end
    end
endmodule


// one leaky integrate-and-fire neuron over T timesteps in one cycle (doc Sec. 8: V = V/2 + x; fire if
// V >= theta, then V -= theta), registered output.
module ours_lif #(parameter T = 8, PSW = 24) (
    input  wire clk, rst, v,
    input  wire [T*PSW-1:0] x,
    input  wire signed [PSW-1:0] theta,
    output reg  [T-1:0] spk
);
    reg signed [PSW+1:0] V;
    reg [T-1:0] s;
    integer t;
    always @(*) begin
        V = 0;
        for (t = 0; t < T; t = t + 1) begin
            V = (V >>> 1) + $signed(x[t*PSW +: PSW]);
            s[t] = (V >= theta);
            if (s[t]) V = V - theta;
        end
    end
    always @(posedge clk or posedge rst)
        if (rst) spk <= 0; else if (v) spk <= s;
endmodule


// run-time packer: 8 pixel slices (R*T = 32 bits) per cycle, first-fit into <= 4 open groups of <= G pixels,
// oldest group evicted when none fits and all are open; full groups leave at once; flush empties all.
module ours_packer #(parameter PP = 8, MW = 32, G = 4, OPEN = 4, PIDW = 7) (
    input  wire                  clk, rst,
    input  wire [PP-1:0]         sl_v,
    input  wire [PP*MW-1:0]      sl_m,
    input  wire [PP*PIDW-1:0]    sl_id,
    input  wire                  flush,
    output reg  [PP+OPEN-1:0]    gv,              // emitted groups this cycle
    output reg  [(PP+OPEN)*MW-1:0] gm,            // combined spike bits
    output reg  [(PP+OPEN)*2*MW-1:0] gl,          // 2-bit pixel label per bit
    output reg  [(PP+OPEN)*G*PIDW-1:0] gid        // pixel ids
);
    localparam GW = 1 + 3 + MW + 2*MW + G*PIDW;   // valid, count, mask, labels, ids
    reg [GW-1:0] q [0:OPEN-1], nq [0:OPEN-1];
    reg [GW-1:0] cur, tmp;
    reg [PP+OPEN-1:0] ev;
    reg [GW-1:0] eg [0:PP+OPEN-1];
    reg [MW-1:0] m;
    reg found;
    integer i, j, k, b;
    // field helpers
    `define GV(x)   x[GW-1]
    `define GC(x)   x[GW-2 -: 3]
    `define GM(x)   x[GW-5 -: MW]
    `define GL(x)   x[GW-5-MW -: 2*MW]
    `define GI(x)   x[G*PIDW-1:0]
    always @(*) begin
        found = 0; m = 0; tmp = 0; cur = 0;
        for (j = 0; j < OPEN; j = j + 1) nq[j] = q[j];
        ev = 0;
        for (j = 0; j < PP + OPEN; j = j + 1) eg[j] = 0;
        for (i = 0; i < PP; i = i + 1) begin
            m = sl_m[i*MW +: MW];
            if (sl_v[i] && m != 0) begin
                found = 0;
                for (j = 0; j < OPEN; j = j + 1) begin
                    if (!found && `GV(nq[j]) && ((`GM(nq[j]) & m) == 0)) begin
                        found = 1;
                        tmp = nq[j];
                        for (b = 0; b < MW; b = b + 1)
                            if (m[b]) tmp[GW-5-MW-(2*MW-1) + 2*b +: 2] = `GC(tmp);
                        tmp[(`GC(tmp))*PIDW +: PIDW] = sl_id[i*PIDW +: PIDW];
                        `GM(tmp) = `GM(tmp) | m;
                        `GC(tmp) = `GC(tmp) + 1;
                        if (`GC(tmp) == G) begin           // full: emit and close
                            ev[i] = 1; eg[i] = tmp;
                            for (k = j; k < OPEN - 1; k = k + 1) nq[k] = nq[k+1];
                            nq[OPEN-1] = 0;
                        end else
                            nq[j] = tmp;
                    end
                end
                if (!found) begin
                    if (`GV(nq[OPEN-1])) begin           // all open: evict the oldest
                        ev[i] = 1; eg[i] = nq[0];
                        for (k = 0; k < OPEN - 1; k = k + 1) nq[k] = nq[k+1];
                        nq[OPEN-1] = 0;
                    end
                    tmp = 0;
                    `GV(tmp) = 1; `GC(tmp) = 1; `GM(tmp) = m;
                    tmp[PIDW-1:0] = sl_id[i*PIDW +: PIDW];
                    // labels default 0 = pixel 0 of the group
                    found = 0;
                    for (k = 0; k < OPEN; k = k + 1)
                        if (!found && !`GV(nq[k])) begin nq[k] = tmp; found = 1; end
                end
            end
        end
        if (flush)
            for (j = 0; j < OPEN; j = j + 1) begin
                ev[PP + j] = `GV(nq[j]); eg[PP + j] = nq[j]; nq[j] = 0;
            end
    end
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            for (j = 0; j < OPEN; j = j + 1) q[j] <= 0;
            gv <= 0; gm <= 0; gl <= 0; gid <= 0;
        end else begin
            for (j = 0; j < OPEN; j = j + 1) q[j] <= nq[j];
            gv <= ev;
            for (j = 0; j < PP + OPEN; j = j + 1) begin
                gm[j*MW +: MW] <= `GM(eg[j]);
                gl[j*2*MW +: 2*MW] <= `GL(eg[j]);
                gid[j*G*PIDW +: G*PIDW] <= `GI(eg[j]);
            end
        end
    end
    `undef GV
    `undef GC
    `undef GM
    `undef GL
    `undef GI
endmodule


module ours_core #(parameter R = 4, C = 4, T = 8, F = 4, G = 4, SW = 10, PSW = 24, E = 4,
                   NLIF = 16, PP = 8, FIDW = 6, PIDW = 7) (
    input  wire clk, rst,
    // ---- array injection (row 0 timing; rows k>0 are skewed by k cycles inside)
    input  wire                    inj_v, inj_par,
    input  wire [R*T-1:0]          inj_bits,
    input  wire [R*2*T-1:0]        inj_lab,
    input  wire [G*PIDW-1:0]       inj_pid,          // pixel ids of the group
    input  wire [C*F*FIDW-1:0]     inj_fid,          // filter ids of every column for this pass
    // ---- shadow weight loads, one port per PE
    input  wire [R*C-1:0]          wl_en,
    input  wire [R*C*8-1:0]        wl_w,
    input  wire [R*C*2-1:0]        wl_f,
    input  wire [R*C-1:0]          wl_par,
    // ---- output buffer read-modify-write, E ports per column (async read, write at clock edge)
    output wire [C*E-1:0]          obuf_we,
    output wire [C*E*(FIDW+PIDW)-1:0] obuf_addr,
    input  wire [C*E*T*PSW-1:0]    obuf_rdata,
    output wire [C*E*T*PSW-1:0]    obuf_wdata,
    output wire [C-1:0]            fifo_overflow,
    // ---- LIF sweep
    input  wire [NLIF-1:0]         lif_v,
    input  wire [NLIF*T*PSW-1:0]   lif_x,
    input  wire signed [PSW-1:0]   theta,
    output wire [NLIF*T-1:0]       lif_spk,
    // ---- packer
    input  wire [PP-1:0]           sl_v,
    input  wire [PP*R*T-1:0]       sl_m,
    input  wire [PP*PIDW-1:0]      sl_id,
    input  wire                    pk_flush,
    output wire [PP+4-1:0]         pk_gv,
    output wire [(PP+4)*R*T-1:0]   pk_gm,
    output wire [(PP+4)*2*R*T-1:0] pk_gl,
    output wire [(PP+4)*G*PIDW-1:0] pk_gid
);
    localparam NS = F * G, BW = NS * T * SW, EW = FIDW + PIDW + T * SW;

    // ---------------- feeder skew: row k sees the injection k cycles later
    localparam IW = 1 + 1 + T + 2*T;
    wire [IW-1:0] row_in [0:R-1];
    genvar k, c, e, tt;
    generate for (k = 0; k < R; k = k + 1) begin : feed
        wire [IW-1:0] now = {inj_v, inj_par, inj_bits[k*T +: T], inj_lab[k*2*T +: 2*T]};
        if (k == 0) begin : z
            assign row_in[0] = now;
        end else begin : d
            reg [IW-1:0] sk [1:k];
            integer i;
            always @(posedge clk or posedge rst)
                if (rst) for (i = 1; i <= k; i = i + 1) sk[i] <= 0;
                else begin
                    sk[1] <= now;
                    for (i = 2; i <= k; i = i + 1) sk[i] <= sk[i-1];
                end
            assign row_in[k] = sk[k];
        end
    end endgenerate

    // ---------------- PE array
    wire           sv [0:R-1][0:C];
    wire           sp [0:R-1][0:C];
    wire [T-1:0]   sb [0:R-1][0:C];
    wire [2*T-1:0] sl [0:R-1][0:C];
    wire [BW-1:0]  bs [0:R][0:C-1];
    wire [NS-1:0]  bt [0:R][0:C-1];
    generate
        for (k = 0; k < R; k = k + 1) begin : rowin
            assign {sv[k][0], sp[k][0], sb[k][0], sl[k][0]} = row_in[k];
        end
        for (c = 0; c < C; c = c + 1) begin : top
            assign bs[0][c] = {BW{1'b0}};
            assign bt[0][c] = {NS{1'b0}};
        end
        for (k = 0; k < R; k = k + 1) begin : r
            for (c = 0; c < C; c = c + 1) begin : col
                localparam P = k * C + c;
                ours_pe #(.T(T), .F(F), .G(G), .SW(SW)) pe (
                    .clk(clk), .rst(rst),
                    .wl_en(wl_en[P]), .wl_par(wl_par[P]), .wl_w(wl_w[P*8 +: 8]), .wl_f(wl_f[P*2 +: 2]),
                    .i_v(sv[k][c]), .i_par(sp[k][c]), .i_bits(sb[k][c]), .i_lab(sl[k][c]),
                    .b_sum(bs[k][c]), .b_tch(bt[k][c]),
                    .o_v(sv[k][c+1]), .o_par(sp[k][c+1]), .o_bits(sb[k][c+1]), .o_lab(sl[k][c+1]),
                    .ob_sum(bs[k+1][c]), .ob_tch(bt[k+1][c]));
            end
        end
    endgenerate

    // ---------------- id sideband: column c needs the ids R + c cycles after injection
    localparam IDW = G * PIDW + F * FIDW;
    generate for (c = 0; c < C; c = c + 1) begin : ids
        localparam L = R + c;
        reg [IDW-1:0] dl [1:L];
        integer d;
        always @(posedge clk or posedge rst)
            if (rst) for (d = 1; d <= L; d = d + 1) dl[d] <= 0;
            else begin
                dl[1] <= {inj_pid, inj_fid[c*F*FIDW +: F*FIDW]};
                for (d = 2; d <= L; d = d + 1) dl[d] <= dl[d-1];
            end
        wire [G*PIDW-1:0] pid = dl[L][IDW-1 -: G*PIDW];
        wire [F*FIDW-1:0] fid = dl[L][F*FIDW-1:0];

        // ---- edge unit: entries of the touched slots -> FIFO -> E read-modify-writes
        wire [NS*EW-1:0] wd;
        for (e = 0; e < NS; e = e + 1) begin : ent
            wire [T*SW-1:0] sums;
            for (tt = 0; tt < T; tt = tt + 1) begin : ts
                assign sums[tt*SW +: SW] = bs[R][c][(e*T + tt)*SW +: SW];
            end
            assign wd[e*EW +: EW] = {fid[(e / G)*FIDW +: FIDW], pid[(e % G)*PIDW +: PIDW], sums};
        end
        wire [E-1:0] rv;
        wire [E*EW-1:0] rd;
        wire [7:0] cnt;
        ours_edge_fifo #(.EW(EW), .NS(NS), .E(E)) fifo (
            .clk(clk), .rst(rst), .wr_v(bt[R][c]), .wr_d(wd), .rd_v(rv), .rd_d(rd),
            .count(cnt), .overflow(fifo_overflow[c]));
        for (e = 0; e < E; e = e + 1) begin : rmw
            localparam Q = c * E + e;
            wire [EW-1:0] ent = rd[e*EW +: EW];
            assign obuf_we[Q] = rv[e];
            assign obuf_addr[Q*(FIDW+PIDW) +: FIDW+PIDW] = ent[EW-1 -: FIDW+PIDW];
            for (tt = 0; tt < T; tt = tt + 1) begin : add
                wire signed [SW-1:0] v = ent[tt*SW +: SW];
                assign obuf_wdata[(Q*T + tt)*PSW +: PSW] =
                    $signed(obuf_rdata[(Q*T + tt)*PSW +: PSW]) + {{(PSW-SW){v[SW-1]}}, v};
            end
        end
    end endgenerate

    // ---------------- LIF units
    generate for (e = 0; e < NLIF; e = e + 1) begin : lif
        ours_lif #(.T(T), .PSW(PSW)) u (.clk(clk), .rst(rst), .v(lif_v[e]), .x(lif_x[e*T*PSW +: T*PSW]),
                                        .theta(theta), .spk(lif_spk[e*T +: T]));
    end endgenerate

    // ---------------- packer
    ours_packer #(.PP(PP), .MW(R*T), .G(G), .OPEN(4), .PIDW(PIDW)) packer (
        .clk(clk), .rst(rst), .sl_v(sl_v), .sl_m(sl_m), .sl_id(sl_id), .flush(pk_flush),
        .gv(pk_gv), .gm(pk_gm), .gl(pk_gl), .gid(pk_gid));
endmodule
